#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(rvest)  
library(stringr)

SCI <- function(doi) {
    library(rvest)  
    library(stringr)
    web <- paste0("https://sci-hub.do/", doi) 
    web_info <- read_html(web, encoding = "UTF-8")    
    web_target <- html_nodes(web_info, "#pdf")
    mypdf <- html_attr(web_target, name = "src")
}



shinyServer( 
    function(input, output) {
        output$pdfviewer <- renderText({   aaa = SCI(input$text)
            return(paste('<iframe style="height:1000px; width:100%" src="', aaa, '"></iframe>', sep = ""))
        })
        
    }
)